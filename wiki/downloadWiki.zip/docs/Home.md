**Project Description**
This is a simple application created to make things a little easier when downloading a whole album worth of mp3s from the gomusicnow.com web site.

To use, simply add your gomusicnow username and password, choose a local folder to download the mp3s to, then paste the url of the gomusicnow 'links' page, for the album you have purchased. Once you hit start, the files will be downloaded sequentially.

This application is my first windows application, and first time using WPF. Therefore, I cannot vouch for it adhering to good coding practices. Suggestions for improvement are welcome.

I am in no way associated with the GoMusicNow.com web site. This utility was created for my personal use, and released in the hope someone may find either the application or the source code useful.

